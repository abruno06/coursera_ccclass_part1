#!/bin/bash

for i in 2008
do
/home/ubuntu/impdata_kafka-2008.sh ${i}
done
