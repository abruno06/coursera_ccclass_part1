#!/bin/bash

#for i in 1988
for i in 1999 2000 2001 2002 2003 2004 2005 2006 2007 2008
do
/home/ubuntu/impdata_demo.sh ${i}
done
